<template>
    <!-- <h1> This is a TodoItem component </h1> -->
    <li class="item">{{xyz}}</li>
</template>
<script>
export default {
    props: ['xyz'],
}
</script>

<style scoped>
.item{
    font: 18px Calibri;
    background-color: #abc;
    margin: 5px;
    padding: 5px;
}
.item:hover{
    background-color: #cba;
    cursor: pointer;
}
h1{
    color: green;
}
</style>