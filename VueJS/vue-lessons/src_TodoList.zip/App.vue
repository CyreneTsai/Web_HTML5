<script>
import TodoList from './TodoList.vue';

export default {
    components: {
        TodoList,
    },
}
</script>
<template>
    <todo-list></todo-list>
</template>