<script>
import TodoInput from './TodoInput.vue';
import TodoItem from './TodoItem.vue';

export default {
    components: {
        TodoInput,
        TodoItem,
    },
    data(){
        return {
            tasks: [],
        }
    },
    methods: {
        addTask(item){
            this.tasks.push(item)
        },
        removeTask(index){
            this.tasks.splice(index, 1)
        },
    },
}
</script>
<template>
    <!-- <h1> This is a TodoList component </h1> -->
    <todo-input @abc="addTask"></todo-input>
    <ol>
        <todo-item v-for="(task,index) in tasks" :xyz="task" @click="removeTask(index)"></todo-item>
    </ol>
</template>

<style scoped>
h1{
    color: red;
}
</style>